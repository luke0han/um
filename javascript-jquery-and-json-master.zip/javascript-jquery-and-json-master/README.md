# Course Repo
- **Title:** JavaScript, jQuery, and JSON
- **Taught by:** Charles Russell Severance
- **Platform:** Coursera
- **Note(s):** Part of the Web Applications for Everybody Specialization offered by the University of Michigan
